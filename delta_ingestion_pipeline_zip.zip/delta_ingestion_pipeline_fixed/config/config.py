EMAIL = "your_email@example.com"
APP_PASSWORD = "your_app_password"
RECEIVER = "receiver_email@example.com"
INTERVAL_MINUTES = 5
TIMEZONE = "Asia/Kolkata"
NUM_ROWS = 5
DELTA_PATH = "../delta_table"